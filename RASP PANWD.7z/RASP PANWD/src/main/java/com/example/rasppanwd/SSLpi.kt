import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.Request
import java.security.MessageDigest
import java.security.cert.X509Certificate
import android.util.Base64

class SSLPinning(private val expectedHash: String, private val domain: String) {

    // Método para realizar a conexão e validar o certificado
    fun validateCertificate(): Boolean {
        // Configurar o OkHttpClient com o CertificatePinner
        val certificatePinner = CertificatePinner.Builder()
            .add(domain, "sha256/$expectedHash")
            .build()

        val client = OkHttpClient.Builder()
            .certificatePinner(certificatePinner)
            .build()

        return try {
            // Fazer uma requisição ao domínio
            val request = Request.Builder()
                .url("https://$domain")
                .build()

            val response = client.newCall(request).execute()

            // Se a resposta for bem-sucedida, o certificado é válido
            response.isSuccessful
        } catch (e: Exception) {
            // Em caso de erro, a verificação falhou
            false
        }
    }

    // Método auxiliar para obter o hash do certificado do site
    fun getSiteCertificateHash(): String? {
        return try {
            // Configurar um cliente OkHttp sem pinning para pegar o certificado
            val client = OkHttpClient()

            val request = Request.Builder()
                .url("https://$domain")
                .build()

            val response = client.newCall(request).execute()
            val certificates = response.handshake?.peerCertificates ?: return null

            // Pegar o primeiro certificado (assumindo que é o certificado principal)
            val certificate = certificates[0] as X509Certificate

            // Obter o hash do certificado (SHA-256)
            val digest = MessageDigest.getInstance("SHA-256")
            val publicKey = certificate.publicKey.encoded
            val hashBytes = digest.digest(publicKey)

            // Converter o hash para uma string Base64
            Base64.encodeToString(hashBytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }
}