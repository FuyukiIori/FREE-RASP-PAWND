package com.example.rasppanwd

import android.app.ActivityManager
import android.content.Context
import java.net.InetSocketAddress
import java.net.Socket

fun Frisk(context: Context): Boolean {
    var returnValue = false

    // Get currently running application processes
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val list = manager.getRunningServices(300)

    list?.let {
        for (serviceInfo in it) {
            if (serviceInfo.process.contains("fridaserver")) {
                returnValue = true
            }
        }
    }

    return returnValue
}
fun Frisk2(): Pair<Boolean, Int> {
    for (i in 0..65535) {
        try {
            val sock = Socket("localhost", i)
            sock.outputStream.write(0)
            sock.outputStream.write("AUTH\r\n".toByteArray())

            Thread.sleep(100)

            val res = ByteArray(7)
            val ret = sock.inputStream.read(res)

            if (ret != -1 && String(res, 0, 6) == "REJECT") {
                sock.close()
                return true to i
            }

            sock.close()
        } catch (e: Exception) {
            // Handle exception
        }
    }
    return false to -1
}
fun Frisk3(): Boolean {
    val serverAddress = "127.0.0.1"
    val serverPort = 27042

    return try {
        val socket = Socket()
        socket.connect(InetSocketAddress(serverAddress, serverPort), 1000)
        socket.close()
        true
    } catch (e: Exception) {
        false
    }
}
