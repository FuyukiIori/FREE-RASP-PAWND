package com.example.rasppanwd
import SSLPinning
import android.content.Context
import android.content.pm.ApplicationInfo
import android.app.AlertDialog
import android.R

class HAUNTER {



    fun initialize(context: Context, domain: String, expectedHash: String) {
        val sslPinning = SSLPinning(expectedHash, domain)

        // Validação do certificado
        val isValid = sslPinning.validateCertificate()
        println("Certificado é válido: $isValid")

        // Pegar o hash do certificado do site
        val siteCertHash = sslPinning.getSiteCertificateHash()
        println("Hash do certificado do site: $siteCertHash")

        // Realizar verificação extra (caso exista a implementação de realizarVerificacao)
        realizarVerificacao(context)
    }


    fun Debugante(context: Context): Boolean {
        val applicationInfo = context.applicationInfo
        return applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
    }

    fun realizarVerificacao(context: Context) {
        // Utiliza a função Debugante para verificar o modo de depuração
        val HUULK = Frisk(context)
        val HUULK2 = Frisk2()
        val HUULK3 = Frisk3()
        val isDebuggable = Debugante(context)
        val Root = TryRootMe()
        val Root2 = TryRootMe2("/")
        val Root3 = TryRootMe3()
        val Emulador = EumEmulador()
        if (Emulador){

            EmuladorLock(context, "Emulador Detectado")
        }

        if (HUULK3 || HUULK2.first || HUULK || Root || Root2 || Root3 || isDebuggable) {
            // Se estiver em modo de depuração, bloqueia a tela
            lockScreen(context,"Ambiente Inseguro")
        } else {
            // Caso contrário, continua normalmente
            println("O aplicativo não está em modo de depuração.")
        }
    }

private fun lockScreen(context: Context, message: String) {
    AlertDialog.Builder(context)
        .setTitle("AVISO!!")
        .setMessage(message)
        .setPositiveButton(R.string.ok) { _, _ ->
            // Forçar um travamento do aplicativo
            throw RuntimeException("Segurança Violada! Sessão Terminada.")
        }
        .setCancelable(false)
        .show()

}

    private fun EmuladorLock(context: Context, message: String) {
        AlertDialog.Builder(context)
            .setTitle("AVISO!!")
            .setMessage(message)
            .setPositiveButton(R.string.ok) { _, _ ->
                // Forçar um travamento do aplicativo
                throw RuntimeException("Segurança Violada! Sessão Terminada.")
            }
            .setCancelable(false)
            .show()

    }
    }



