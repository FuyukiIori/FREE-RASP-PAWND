package com.example.rasppanwd

import android.content.Context
import java.io.File
import java.io.IOException

//verifica propriedades do sistema.
fun TryRootMe(): Boolean {
    val properties = arrayOf(
        "ro.debuggable",
        "ro.build.tags",
        "ro.build.type",
        "ro.build.selinux"
    )

    try {
        for (property in properties) {
            val value = Runtime.getRuntime().exec("getprop $property").inputStream.bufferedReader().readText()
            if (value.contains("test-keys") || value.contains("userdebug") || value.contains("eng")) {
                return true
            }
        }
    } catch (e: Exception) {

    }

    return false
}


//tenta manipular arquivos em um diretório específico.
fun TryRootMe2(directoryPath: String): Boolean {
    val directory = File(directoryPath)
    if (!directory.exists() || !directory.isDirectory) {
        return false
    }

    val testFile = File(directory, "TENTATIVA.txt")
    return try {
        testFile.createNewFile()
        testFile.delete()
        true
    } catch (e: IOException) {
        false
    }
}

//procura pelo comando su no caminho do sistema.
fun TryRootMe3(): Boolean {
    val pathDirs = System.getenv("PATH")?.split(":") ?: return false
    for (pathDir in pathDirs) {
        val suFile = File(pathDir, "su")
        if (suFile.exists()) {
            return true
        }
    }
    return false
}

